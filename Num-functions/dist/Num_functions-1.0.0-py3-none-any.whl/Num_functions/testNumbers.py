import Numfunctions
a=Numfunctions.isprime(407)
print (a)

b=Numfunctions.isodd(51432)
print(b)

c=Numfunctions.digreverse(995186)
print(c)

Numfunctions.prteven(123456789)

Numfunctions.prtprime(123456789123456789)
